
public class Find {

	
	public static void main(String[] args) {
		int[] array1 = new int[] { 1,3,4,6,8,};
		
		System.out.println(findK(array1,0,1,8));
	}
	
	public static boolean findK(int[] a, int i, int j, int k){
		 if (a[i] + a[j] == k) return true;
		 else 
			 if (j < a.length-1 ){
			 return findK(a, i, j+1, k);
		}
			 else j = i+1;
		 if (i < a.length-1 ){
		 return findK(a, i+1, j, k);
		 }
		return false;

}
}
		
		
		
		
		
		
		/*if(j == a.length )
			return false;
		else if (a[i] + a[j] == k) return true;
				
				else{
					return findK(a, i, j+1, k);
			}
	}	
}*/


